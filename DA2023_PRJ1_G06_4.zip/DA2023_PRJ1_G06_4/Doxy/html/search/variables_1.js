var searchData=
[
  ['parent_0',['parent',['../_network_8cpp.html#a92d810e9dac1a24b3b01862bb8f66385',1,'Network.cpp']]]
];
