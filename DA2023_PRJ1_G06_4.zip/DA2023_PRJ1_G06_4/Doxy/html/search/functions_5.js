var searchData=
[
  ['getcapacity_0',['getCapacity',['../class_trip.html#abe2c29e52c6eda8d6cae767254f95b08',1,'Trip']]],
  ['getdestination_1',['getDestination',['../class_trip.html#a401e9921e58295d035e85d8a1d6ada82',1,'Trip']]],
  ['getdistrict_2',['getDistrict',['../class_station.html#adfeb6e1c7361d9de1a8efade27b82c7c',1,'Station']]],
  ['getincomingtrips_3',['getIncomingTrips',['../class_station.html#a7202e36e137cd2d609e253b4f9d7955e',1,'Station']]],
  ['getline_4',['getLine',['../class_station.html#a29859ce5b681749459b415b3bf86ae81',1,'Station']]],
  ['getmun_5',['getMun',['../class_station.html#a549750db5cf138c591ebcbe03276867b',1,'Station']]],
  ['getname_6',['getName',['../class_station.html#ac823ae175ec0e2baff462ed9612c7bae',1,'Station']]],
  ['getorigin_7',['getOrigin',['../class_trip.html#a8ec2b91cc4a64ac15e7e5320d9c985d6',1,'Trip']]],
  ['getrealstations_8',['getRealStations',['../class_network.html#aa1e0a287f0f27c73aad215c91745fd42',1,'Network']]],
  ['getresidual_9',['getResidual',['../class_network.html#a7f3be68831e1da8a4d6810269ba0c816',1,'Network']]],
  ['getservice_10',['getService',['../class_trip.html#ae3f390f72451291fe3e5de2382ceba63',1,'Trip']]],
  ['getstationsnametoindex_11',['getStationsNameToIndex',['../class_network.html#a13c5a0a95a6f245348fb1e722a4022e9',1,'Network']]],
  ['gettownship_12',['getTownship',['../class_station.html#a1e3c26415e7886648ea5e1a9dfddcdde',1,'Station']]],
  ['gettrips_13',['getTrips',['../class_station.html#a2548bf8b9d1a6d2d5f5c7c8897586e0d',1,'Station']]]
];
