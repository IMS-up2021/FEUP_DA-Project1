var searchData=
[
  ['network_0',['Network',['../class_network.html#a3cc2fb4f8fa4d507077e8da85ce5a1c8',1,'Network']]],
  ['networkdisplay_1',['networkDisplay',['../class_interface.html#a86796a349b494cae31f3fe06a9fa2ff3',1,'Interface']]]
];
